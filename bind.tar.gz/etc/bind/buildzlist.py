#!/usr/bin/python

import sys, re, os

zline = re.compile(r'.*zone.*')
def stractor(fname):
    bud = file(fname, 'r').readlines()
    for line in bud:
	if zline.match(line):
	    line = line.split()
	    print line[1][1:-1]
	    
	    
if __name__ == "__main__":
    
    stractor(sys.argv[1])
